"""
/***************************************************************************
 GeoSearch
                                 A QGIS plugin
 Search location by words like google map
                              -------------------
        begin                : 2013-07-10
        copyright            : (C) 2013 by Walter Tsui
        email                : waltertech426@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

Description:
A QGIS Plugin Tool for searching locations by address or position(latitude, longtitude).
This tool was built on QGIS build-in geopy.